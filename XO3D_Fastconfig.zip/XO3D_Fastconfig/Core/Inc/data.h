/*
 * data.h
 *
 *  Created on: Jan 1, 2025
 *      Author: Rhodz
 */

#ifndef INC_DATA_H_
#define INC_DATA_H_

extern const int g_iDataSize;  // Declaration of the integer
extern const unsigned char g_pucDataArray[];  // Declaration of the array

#endif /* INC_DATA_H_ */
